


export class Employee{

    
    empId:number;
    empName:string;
    empSal:number;
    empDep:string;
    empjoiningdate:string;

}