const abc: number = 24;

console.log(abc)
