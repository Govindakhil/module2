var abc = 24;
console.log(abc);
