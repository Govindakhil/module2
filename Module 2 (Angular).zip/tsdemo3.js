// function add(a: number,b: number){
//     return(a+b);
// }
// console.log(add(10));
function fun1() {
    var params = [];
    for (var _i = 0; _i < arguments.length; _i++) {
        params[_i] = arguments[_i];
    }
    console.log(params.length);
}
fun1(3, 4, 5);
