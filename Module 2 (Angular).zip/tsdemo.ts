function greeter(person) {
    return "Hello, " + person;
}

var user = "Brock";

document.body.textContent = greeter(user);